**fzutils**

这是什么?
=============

这是fz的常用utils包, for Spider.

要求
=============

-  Python 3或更高版本.
-  依靠的代理池是IPProxyPool < https://github.com/qiyeboy/IPProxyPool >

资源
=============

fzutils的home < https://www.github.com/superonesfazai/python >

版权和保修
=============

此发行版中的代码为版权所有 (c) super_fazai, 除非另有明确说明.

fzutils根据MIT许可证提供, 包含的LICENSE文件详细描述了这一点.

贡献者
============

-  super_fazai

作者
=============

super_fazai

<author_email: superonesfazai@gmail.com>
